#!/usr/bin/env python3
"""Read-only verifier for PADRE_MX 7-Part assembled UTF-8 full scripts.

Count = Python Unicode code points in complete text after removing ONLY
standalone [PART 1]...[PART 7] lines INCLUDING their newline. Hash = SHA256
UTF-8 of that same body. Never modifies the manuscript.

Usage: python verify_full_script.py /mnt/data/PMX_<title_sha12>_FULL_SCRIPT.txt
Returns exit 0 on PASS and 2 on FAIL; emits JSON to stdout.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

HEADING = re.compile(r"^\[PART ([1-7])\]$")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def report(path):
    raw = path.read_bytes()
    failures=[]
    try:
        text=raw.decode('utf-8','strict')
    except UnicodeDecodeError as e:
        return {'path':str(path),'pass':False,'failures':[f'UTF-8 decode error: {e}']}
    if raw.startswith(b'\xef\xbb\xbf'):
        failures.append('UTF-8 BOM not allowed')
    if '\r' in text:
        failures.append('CR/CRLF line ending is not allowed; use LF consistently')
    headings=[]
    body_lines=[]
    part_lengths=[]
    current=None
    for line in text.splitlines(keepends=True):
        ln=line.rstrip('\r\n')
        m=HEADING.fullmatch(ln)
        if m:
            headings.append(int(m.group(1)));
            if current is not None:part_lengths.append(len(current))
            current=''
        else:
            body_lines.append(line)
            if current is None:
                if line.strip(): failures.append('Non-heading manuscript content appears before PART 1')
            else: current+=line
    if current is not None:part_lengths.append(len(current))
    if headings!=list(range(1,8)):
        failures.append(f'Expected exact ordered headings 1..7; found {headings}')
    if len(part_lengths)!=7 or any(n<8500 for n in part_lengths):
        failures.append(f'Half-length/absent Part (minimum 8,500 body chars): {part_lengths}')
    body=''.join(body_lines)
    chars=len(body)
    if not 70000<=chars<=80000:
        failures.append(f'Length hard fail: {chars} not in 70000..80000')
    result={
      'path':str(path),'pass':not failures,'failures':failures,
      'file_bytes':len(raw),'file_sha256':sha(raw),
      'headings':headings,'part_characters_including_prose_whitespace':part_lengths,
      'script_body_chars':chars,'script_body_words':len(body.split()),
      'script_body_sha256':sha(body.encode('utf-8')),
      'count_rule':'Remove only standalone [PART N] heading lines and their line endings',
      'valid_range':'70000..80000 inclusive',
    }
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('path',type=Path)
    ns=ap.parse_args()
    try: res=report(ns.path)
    except OSError as e:
        res={'path':str(ns.path),'pass':False,'failures':[str(e)]}
    print(json.dumps(res,ensure_ascii=False,indent=2))
    raise SystemExit(0 if res['pass'] else 2)

if __name__=='__main__': main()
